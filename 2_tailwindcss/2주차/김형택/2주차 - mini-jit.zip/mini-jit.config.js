export default {
    content: ["src/**/*.{html,js,jsx,ts,tsx}"],
    output: "dist/output.css"
};
